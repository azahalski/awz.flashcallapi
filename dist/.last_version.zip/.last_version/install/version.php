<?
$arModuleVersion = array(
    "VERSION" => "1.0.1",
    "VERSION_DATE" => "2022-11-10 12:29:00"
);